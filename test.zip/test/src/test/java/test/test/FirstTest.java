package test.test;

import org.apache.bcel.generic.Select;
import org.apache.bcel.generic.Visitor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by disha on 02/07/17.
 */
public class FirstTest {

    private WebDriver driver;

    @BeforeClass
    private void setUp(){
        driver = new FirefoxDriver();
    }

    @BeforeMethod
    public void openWebPage(){
      driver.get("https://www.amazon.com/");
    }

    @AfterClass
    private void tearDown(){
        driver.quit();
    }

    @Test
    private void automationtest(){

        //Enter Search key: 'Nikon'
        driver.findElement(By.id("twotabsearchtextbox"))
                .sendKeys("Nikon");

        //Click 'go' button
        driver.findElement(By.xpath("//*[@value='Go']"))
                .click();

        //Sort results from highest to lowest price
        //driver.findElement(By.id("div.custom-select.sort.price-desc-rank")).click();

        //Select s = new Select(driver.findElement(By.id("sort")))
        //       s.selectByVisibleText("price-desc-rank");


        //Click the second search item
        WebElement secondItemTitleElement = driver.findElement(By.className("s-access-title"));
        //This implementation shows the first element. However with Xpath should be able to find the second element.
        //WebElement secondItemTitleElement = firstItemTitleElement.findElement(By.id("s-access-title/following-sibling::div"));
        String secondItemTitle = secondItemTitleElement.getText();
        secondItemTitleElement.click();

        //Verify Product Title
        assert (driver.findElement(By.id("productTitle"))
                .getText()
                .equals(secondItemTitle));

        //Verify Product Topic contains 'Nikon DX3'
        //assert (driver.findElement(By.id("titleSection"))
          //      .getText()
            //    .equals("Nikon DX3"));


    }
}
